import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')

# Load the data without headers, and specify column names manually
df = pd.read_csv('monthly_sales.csv', header=None, names=['Date', 'MonthlySales', 'OrderCount'])

# Add the first row back as data (it was incorrectly treated as header)
first_row = pd.DataFrame([['2011-05-01', 567020.9498, 43]], columns=['Date', 'MonthlySales', 'OrderCount'])
df = pd.concat([first_row, df], ignore_index=True)

# Convert the Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])

# Set date as index
df = df.set_index('Date')

# Convert MonthlySales to numeric format in case it's stored as string
df['MonthlySales'] = pd.to_numeric(df['MonthlySales'])

# Print the first few rows to confirm structure
print("First 5 rows of data after fixing:")
print(df.head())

# Plot the time series
plt.figure(figsize=(12, 6))
plt.plot(df.index, df['MonthlySales'])
plt.title('Monthly Sales Over Time')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.grid(True)
plt.savefig('sales_trend.png')
plt.show()

# Check for missing values
print("Missing values in the dataset:")
print(df.isnull().sum())

# Basic statistics
print("\nBasic statistics of monthly sales:")
print(df['MonthlySales'].describe())

# Create a training and testing split (80% train, 20% test)
train_size = int(len(df) * 0.8)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]

print(f"\nTraining data shape: {train_data.shape}")
print(f"Testing data shape: {test_data.shape}")

# Plot the train-test split
plt.figure(figsize=(12, 6))
plt.plot(train_data.index, train_data['MonthlySales'], label='Training Data')
plt.plot(test_data.index, test_data['MonthlySales'], label='Testing Data', color='red')
plt.title('Train-Test Split of Monthly Sales')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.legend()
plt.grid(True)
plt.savefig('train_test_split.png')
plt.show()

# Add this to your Python file
from sklearn.metrics import mean_squared_error, mean_absolute_error

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Simple Moving Average
def moving_average_forecast(series, window):
    """Forecasts using simple moving average."""
    return series.rolling(window=window).mean()

# Try different window sizes
windows = [3, 6, 12]
plt.figure(figsize=(14, 7))
plt.plot(train_data.index, train_data['MonthlySales'], label='Training Data')
plt.plot(test_data.index, test_data['MonthlySales'], label='Testing Data', color='red')

ma_metrics = []

for window in windows:
    # Create the moving average series
    ma_series = moving_average_forecast(df['MonthlySales'], window)
    
    # Plot the moving average
    plt.plot(df.index, ma_series, label=f'MA (window={window})')
    
    # Calculate metrics on test data
    ma_test = ma_series[test_data.index]
    rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], ma_test))
    mae = mean_absolute_error(test_data['MonthlySales'], ma_test)
    mape = mean_absolute_percentage_error(test_data['MonthlySales'], ma_test)
    
    ma_metrics.append({
        'Model': f'Moving Average (window={window})',
        'RMSE': rmse,
        'MAE': mae,
        'MAPE': mape
    })

plt.title('Moving Average Forecasts')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.legend()
plt.grid(True)
plt.savefig('moving_average_forecasts.png')
plt.show()

# Display metrics
ma_metrics_df = pd.DataFrame(ma_metrics)
print("\nMoving Average Models Performance:")
print(ma_metrics_df)

# Add this to your Python file
from statsmodels.tsa.arima.model import ARIMA
from pmdarima import auto_arima

# Automatically find the best ARIMA parameters
print("\nFinding optimal ARIMA parameters...")
auto_model = auto_arima(
    train_data['MonthlySales'],
    seasonal=True,
    m=12,  # Monthly seasonality
    start_p=0, start_q=0,
    max_p=5, max_q=5,
    d=None,  # Let the model determine 'd'
    trace=True,
    error_action='ignore',
    suppress_warnings=True,
    stepwise=True
)

print(f"\nBest ARIMA model: {auto_model}")
best_order = auto_model.order
best_seasonal_order = auto_model.seasonal_order

# Fit ARIMA model with the best parameters
arima_model = ARIMA(
    train_data['MonthlySales'],
    order=best_order,
    seasonal_order=best_seasonal_order
)
arima_result = arima_model.fit()
print(arima_result.summary())

# Forecast for the test period
arima_forecast = arima_result.forecast(steps=len(test_data))

# Plot the results
plt.figure(figsize=(14, 7))
plt.plot(train_data.index, train_data['MonthlySales'], label='Training Data')
plt.plot(test_data.index, test_data['MonthlySales'], label='Testing Data')
plt.plot(test_data.index, arima_forecast, label='ARIMA Forecast', color='green')
plt.title('ARIMA Forecast')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.legend()
plt.grid(True)
plt.savefig('arima_forecast.png')
plt.show()

# Calculate metrics
arima_rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], arima_forecast))
arima_mae = mean_absolute_error(test_data['MonthlySales'], arima_forecast)
arima_mape = mean_absolute_percentage_error(test_data['MonthlySales'], arima_forecast)

print(f"\nARIMA Model Performance:")
print(f"RMSE: {arima_rmse:.2f}")
print(f"MAE: {arima_mae:.2f}")
print(f"MAPE: {arima_mape:.2f}%")

# Add this to your Python file
from prophet import Prophet

# Prepare data for Prophet (requires 'ds' and 'y' columns)
prophet_data = train_data.reset_index().rename(columns={'Date': 'ds', 'MonthlySales': 'y'})

# Initialize and fit the model
prophet_model = Prophet(
    yearly_seasonality=True,
    weekly_seasonality=False,
    daily_seasonality=False,
    seasonality_mode='multiplicative'
)
prophet_model.fit(prophet_data)

# Create a dataframe for future predictions
future = prophet_model.make_future_dataframe(periods=len(test_data), freq='MS')
prophet_forecast = prophet_model.predict(future)

# Plot the forecast
fig = prophet_model.plot(prophet_forecast)
plt.title('Prophet Forecast')
plt.savefig('prophet_forecast.png')
plt.show()

# Plot the components
fig = prophet_model.plot_components(prophet_forecast)
plt.savefig('prophet_components.png')
plt.show()

# Extract the forecast for the test period
prophet_test_forecast = prophet_forecast.loc[prophet_forecast['ds'].isin(test_data.index), 'yhat']

# Calculate metrics
prophet_rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], prophet_test_forecast.values))
prophet_mae = mean_absolute_error(test_data['MonthlySales'], prophet_test_forecast.values)
prophet_mape = mean_absolute_percentage_error(test_data['MonthlySales'], prophet_test_forecast.values)

print(f"\nProphet Model Performance:")
print(f"RMSE: {prophet_rmse:.2f}")
print(f"MAE: {prophet_mae:.2f}")
print(f"MAPE: {prophet_mape:.2f}%")

# Add this to your Python file
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
from sklearn.preprocessing import MinMaxScaler

# Scale the data
scaler = MinMaxScaler()
train_scaled = scaler.fit_transform(train_data[['MonthlySales']])
test_scaled = scaler.transform(test_data[['MonthlySales']])

# Create sequences for LSTM
def create_sequences(data, seq_length):
    X, y = [], []
    for i in range(len(data) - seq_length):
        X.append(data[i:i + seq_length, 0])
        y.append(data[i + seq_length, 0])
    return np.array(X), np.array(y)

# Use 12 months of data to predict the next month
seq_length = 12
X_train, y_train = create_sequences(train_scaled, seq_length)

# Reshape input to be [samples, time steps, features]
X_train = X_train.reshape(X_train.shape[0], X_train.shape[1], 1)

# Build LSTM model
model = Sequential()
model.add(LSTM(50, return_sequences=True, input_shape=(seq_length, 1)))
model.add(Dropout(0.2))
model.add(LSTM(50))
model.add(Dropout(0.2))
model.add(Dense(1))
model.compile(optimizer='adam', loss='mean_squared_error')

# Train the model
print("\nTraining LSTM model...")
history = model.fit(
    X_train, y_train,
    epochs=100,
    batch_size=32,
    validation_split=0.2,
    verbose=1
)

# Plot training history
plt.figure(figsize=(10, 6))
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('LSTM Model Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()
plt.grid(True)
plt.savefig('lstm_training.png')
plt.show()

# Prepare data for prediction
# We need to create a rolling prediction for the test period
lstm_predictions = []
current_batch = train_scaled[-seq_length:].reshape(1, seq_length, 1)

for i in range(len(test_data)):
    # Predict the next value
    current_pred = model.predict(current_batch)[0]
    lstm_predictions.append(current_pred[0])
    
    # Update the batch to include the new prediction
    current_batch = np.append(current_batch[:, 1:, :], 
                             [[current_pred]], 
                             axis=1)

# Inverse transform to get actual values
lstm_predictions = scaler.inverse_transform(np.array(lstm_predictions).reshape(-1, 1))

# Plot the results
plt.figure(figsize=(14, 7))
plt.plot(train_data.index, train_data['MonthlySales'], label='Training Data')
plt.plot(test_data.index, test_data['MonthlySales'], label='Testing Data')
plt.plot(test_data.index, lstm_predictions, label='LSTM Forecast', color='purple')
plt.title('LSTM Forecast')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.legend()
plt.grid(True)
plt.savefig('lstm_forecast.png')
plt.show()

# Calculate metrics
lstm_rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], lstm_predictions))
lstm_mae = mean_absolute_error(test_data['MonthlySales'], lstm_predictions)
lstm_mape = mean_absolute_percentage_error(test_data['MonthlySales'], lstm_predictions)

print(f"\nLSTM Model Performance:")
print(f"RMSE: {lstm_rmse:.2f}")
print(f"MAE: {lstm_mae:.2f}")
print(f"MAPE: {lstm_mape:.2f}%")


# Add this to your Python file
# Compare all models
models_comparison = pd.DataFrame([
    {'Model': 'Moving Average (best)', 'RMSE': ma_metrics_df.loc[ma_metrics_df['RMSE'].idxmin()]['RMSE'], 
     'MAE': ma_metrics_df.loc[ma_metrics_df['RMSE'].idxmin()]['MAE'], 
     'MAPE': ma_metrics_df.loc[ma_metrics_df['RMSE'].idxmin()]['MAPE']},
    {'Model': 'ARIMA', 'RMSE': arima_rmse, 'MAE': arima_mae, 'MAPE': arima_mape},
    {'Model': 'Prophet', 'RMSE': prophet_rmse, 'MAE': prophet_mae, 'MAPE': prophet_mape},
    {'Model': 'LSTM', 'RMSE': lstm_rmse, 'MAE': lstm_mae, 'MAPE': lstm_mape}
])

print("\nModel Comparison:")
print(models_comparison.sort_values('RMSE'))

# Identify the best model based on RMSE
best_model = models_comparison.loc[models_comparison['RMSE'].idxmin()]['Model']
print(f"\nBest performing model based on RMSE: {best_model}")

# Generate future forecasts for 12 months ahead with the best model
print("\nGenerating 12-month forecast with the best model...")

# Get the last date in our dataset
last_date = df.index[-1]

# Create future dates for 12 months ahead
future_dates = pd.date_range(start=last_date + pd.DateOffset(months=1), periods=12, freq='MS')

# Depending on which model performed best, use that for the final forecast
if 'ARIMA' in best_model:
    # Refit ARIMA on the full dataset
    final_arima = ARIMA(df['MonthlySales'], order=best_order, seasonal_order=best_seasonal_order)
    final_arima_result = final_arima.fit()
    future_forecast = final_arima_result.forecast(steps=12)
    future_df = pd.DataFrame({'Date': future_dates, 'Forecast': future_forecast})
    
elif 'Prophet' in best_model:
    # Refit Prophet on the full dataset
    final_prophet_data = df.reset_index().rename(columns={'Date': 'ds', 'MonthlySales': 'y'})
    final_prophet = Prophet(yearly_seasonality=True, weekly_seasonality=False, daily_seasonality=False)
    final_prophet.fit(final_prophet_data)
    future = final_prophet.make_future_dataframe(periods=12, freq='MS')
    forecast = final_prophet.predict(future)
    future_df = pd.DataFrame({
        'Date': forecast['ds'].iloc[-12:],
        'Forecast': forecast['yhat'].iloc[-12:]
    })
    
elif 'LSTM' in best_model:
    # Refit LSTM on the full dataset
    full_scaled = scaler.fit_transform(df[['MonthlySales']])
    X_full, y_full = create_sequences(full_scaled, seq_length)
    X_full = X_full.reshape(X_full.shape[0], X_full.shape[1], 1)
    
    # Rebuild and train the model
    final_lstm = Sequential()
    final_lstm.add(LSTM(50, return_sequences=True, input_shape=(seq_length, 1)))
    final_lstm.add(Dropout(0.2))
    final_lstm.add(LSTM(50))
    final_lstm.add(Dropout(0.2))
    final_lstm.add(Dense(1))
    final_lstm.compile(optimizer='adam', loss='mean_squared_error')
    final_lstm.fit(X_full, y_full, epochs=100, batch_size=32, verbose=0)
    
    # Generate predictions
    lstm_future = []
    current_batch = full_scaled[-seq_length:].reshape(1, seq_length, 1)
    
    for i in range(12):
        current_pred = final_lstm.predict(current_batch)[0]
        lstm_future.append(current_pred[0])
        current_batch = np.append(current_batch[:, 1:, :], [[current_pred]], axis=1)
    
    lstm_future = scaler.inverse_transform(np.array(lstm_future).reshape(-1, 1))
    future_df = pd.DataFrame({'Date': future_dates, 'Forecast': lstm_future.flatten()})
    
else:  # Moving Average
    # Find the best window size
    best_window = int(ma_metrics_df.loc[ma_metrics_df['RMSE'].idxmin()]['Model'].split('=')[1].strip(')'))
    # Calculate the moving average for the last 'best_window' months
    last_values = df['MonthlySales'].iloc[-best_window:].mean()
    # Create a dataframe with the same forecast value for all future months
    future_df = pd.DataFrame({'Date': future_dates, 'Forecast': [last_values] * 12})

# Plot the historical data and future forecast
plt.figure(figsize=(14, 7))
plt.plot(df.index, df['MonthlySales'], label='Historical Sales')
plt.plot(future_df['Date'], future_df)