import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')
from sklearn.metrics import mean_squared_error, mean_absolute_error

# Load the data without headers, and specify column names manually
df = pd.read_csv('monthly_sales.csv', header=None, names=['Date', 'MonthlySales', 'OrderCount'])

# Add the first row back as data (it was incorrectly treated as header)
first_row = pd.DataFrame([['2011-05-01', 567020.9498, 43]], columns=['Date', 'MonthlySales', 'OrderCount'])
df = pd.concat([first_row, df], ignore_index=True)

# Convert the Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])

# Set date as index
df = df.set_index('Date')

# Convert MonthlySales to numeric format in case it's stored as string
df['MonthlySales'] = pd.to_numeric(df['MonthlySales'])

# Create a training and testing split (80% train, 20% test)
train_size = int(len(df) * 0.8)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]

# Function to calculate MAPE
def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Simple Moving Average
def moving_average_forecast(series, window):
    """Forecasts using simple moving average."""
    return series.rolling(window=window).mean()

# Try different window sizes
windows = [3, 6, 12]
plt.figure(figsize=(14, 7))
plt.plot(train_data.index, train_data['MonthlySales'], label='Training Data')
plt.plot(test_data.index, test_data['MonthlySales'], label='Testing Data', color='red')

ma_metrics = []

for window in windows:
    # Create the moving average series
    ma_series = moving_average_forecast(df['MonthlySales'], window)
    
    # Plot the moving average
    plt.plot(df.index, ma_series, label=f'MA (window={window})')
    
    # Calculate metrics on test data
    ma_test = ma_series[test_data.index]
    rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], ma_test))
    mae = mean_absolute_error(test_data['MonthlySales'], ma_test)
    mape = mean_absolute_percentage_error(test_data['MonthlySales'], ma_test)
    
    ma_metrics.append({
        'Model': f'Moving Average (window={window})',
        'RMSE': rmse,
        'MAE': mae,
        'MAPE': mape
    })

plt.title('Moving Average Forecasts')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.legend()
plt.grid(True)
plt.savefig('moving_average_forecasts.png')
plt.show()

# Display metrics
ma_metrics_df = pd.DataFrame(ma_metrics)
print("\nMoving Average Models Performance:")
print(ma_metrics_df)