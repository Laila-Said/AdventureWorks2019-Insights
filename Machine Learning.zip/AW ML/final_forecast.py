import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime
import warnings
warnings.filterwarnings('ignore')
from statsmodels.tsa.arima.model import ARIMA
from prophet import Prophet

# Load the data without headers, and specify column names manually
df = pd.read_csv('monthly_sales.csv', header=None, names=['Date', 'MonthlySales', 'OrderCount'])

# Add the first row back as data (it was incorrectly treated as header)
first_row = pd.DataFrame([['2011-05-01', 567020.9498, 43]], columns=['Date', 'MonthlySales', 'OrderCount'])
df = pd.concat([first_row, df], ignore_index=True)

# Convert the Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])

# Set date as index
df = df.set_index('Date')

# Convert MonthlySales to numeric format
df['MonthlySales'] = pd.to_numeric(df['MonthlySales'])

# Print dataset information
print(f"Dataset timespan: {df.index.min()} to {df.index.max()}")
print(f"Number of observations: {len(df)}")

# Get the last date in our dataset
last_date = df.index.max()
print(f"Last date in dataset: {last_date}")

# Create future dates for 12 months ahead
future_dates = pd.date_range(start=last_date + pd.DateOffset(months=1), periods=12, freq='MS')
print(f"Forecasting for: {future_dates.min()} to {future_dates.max()}")

print("\n========== GENERATING THREE DIFFERENT FORECASTS ==========")

# ================= Moving Average Forecast =================
print("\n--- Moving Average (6-month window) ---")
# Calculate moving average of the last 6 months
ma_value = df['MonthlySales'].iloc[-6:].mean()
ma_forecast = pd.DataFrame(
    {'Date': future_dates, 'MonthlySales': [ma_value] * 12}
)
print(f"Moving Average forecast (constant): {ma_value:.2f}")

# ================= ARIMA Forecast =================
print("\n--- ARIMA Model ---")
# Use the parameters we found earlier
arima_model = ARIMA(
    df['MonthlySales'],
    order=(2, 1, 0),
    seasonal_order=(0, 0, 0, 12)
)
arima_result = arima_model.fit()
arima_forecast_values = arima_result.forecast(steps=12)
arima_forecast = pd.DataFrame(
    {'Date': future_dates, 'MonthlySales': arima_forecast_values}
)
print("ARIMA forecast for next 12 months:")
for i, (date, value) in enumerate(zip(future_dates, arima_forecast_values)):
    print(f"{date.strftime('%Y-%m')}: {value:.2f}")

# ================= Prophet Forecast =================
print("\n--- Prophet Model ---")
# Prepare data for Prophet
prophet_data = df.reset_index().rename(columns={'Date': 'ds', 'MonthlySales': 'y'})
prophet_model = Prophet(
    yearly_seasonality=True,
    weekly_seasonality=False,
    daily_seasonality=False,
    seasonality_mode='multiplicative'
)
prophet_model.fit(prophet_data)
future = prophet_model.make_future_dataframe(periods=12, freq='MS')
prophet_result = prophet_model.predict(future)
prophet_forecast = pd.DataFrame(
    {'Date': future_dates, 'MonthlySales': prophet_result['yhat'].iloc[-12:].values}
)
print("Prophet forecast for next 12 months:")
for i, (date, value) in enumerate(zip(future_dates, prophet_result['yhat'].iloc[-12:].values)):
    print(f"{date.strftime('%Y-%m')}: {value:.2f}")

# ================= Plotting the Forecasts =================
# Historical data
plt.figure(figsize=(14, 7))
plt.plot(df.index, df['MonthlySales'], label='Historical Sales', color='blue')

# Forecasts
plt.plot(ma_forecast['Date'], ma_forecast['MonthlySales'], 
         label='Moving Average Forecast', color='green', linestyle='--')
plt.plot(arima_forecast['Date'], arima_forecast['MonthlySales'], 
         label='ARIMA Forecast', color='red', linestyle='-.')
plt.plot(prophet_forecast['Date'], prophet_forecast['MonthlySales'], 
         label='Prophet Forecast', color='purple', linestyle=':')

# Formatting
plt.title('Adventure Works: 12-Month Sales Forecast')
plt.xlabel('Date')
plt.ylabel('Sales Amount')
plt.grid(True)
plt.legend()
plt.axvline(x=last_date, color='black', linestyle='-', alpha=0.3)
plt.tight_layout()
plt.savefig('adventure_works_forecast.png')
plt.show()

# Create a comparison table of the forecasts
forecast_comparison = pd.DataFrame({
    'Date': future_dates,
    'Moving Average': ma_forecast['MonthlySales'],
    'ARIMA': arima_forecast['MonthlySales'],
    'Prophet': prophet_forecast['MonthlySales']
})
forecast_comparison.set_index('Date', inplace=True)
print("\n========== FORECAST COMPARISON ==========")
print(forecast_comparison)

# Save the forecast to CSV
forecast_comparison.to_csv('adventure_works_forecast.csv')
print("\nForecast saved to 'adventure_works_forecast.csv'")

# Provide a business interpretation
print("\n========== BUSINESS INSIGHTS ==========")
print("Based on the forecasts, the following business insights can be drawn:")

# Calculate average predicted sales for each model
avg_ma = ma_forecast['MonthlySales'].mean()
avg_arima = arima_forecast['MonthlySales'].mean()
avg_prophet = prophet_forecast['MonthlySales'].mean()
avg_historical = df['MonthlySales'].mean()

print(f"1. Historical average monthly sales: ${avg_historical:.2f}")
print(f"2. Moving Average forecast average: ${avg_ma:.2f} ({(avg_ma-avg_historical)/avg_historical*100:.1f}% change)")
print(f"3. ARIMA forecast average: ${avg_arima:.2f} ({(avg_arima-avg_historical)/avg_historical*100:.1f}% change)")
print(f"4. Prophet forecast average: ${avg_prophet:.2f} ({(avg_prophet-avg_historical)/avg_historical*100:.1f}% change)")

# Find the highest and lowest months
max_month = forecast_comparison.mean(axis=1).idxmax()
min_month = forecast_comparison.mean(axis=1).idxmin()

print(f"\n5. Highest sales are expected in: {max_month.strftime('%B %Y')}")
print(f"6. Lowest sales are expected in: {min_month.strftime('%B %Y')}")

# Final recommendation
print("\n========== RECOMMENDATION ==========")
print("For your Adventure Works sales forecasting project, we recommend:")
print("1. Consider the Prophet model for your final forecast as it captures both trend and seasonality")
print("2. Use the ARIMA model as a complementary forecast for validation")
print("3. The Moving Average provides a simple baseline but may not capture future trends")
print("4. Monitor actual sales against these forecasts monthly to refine future predictions")
print("5. Pay special attention to anticipated peak and low months for inventory planning")