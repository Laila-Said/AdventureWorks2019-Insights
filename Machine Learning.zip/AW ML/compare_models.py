import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Input the metrics manually from your console output
models = []

# Moving Average - Let's get values for all three windows
for window in [3, 6, 12]:
    ma_rmse = float(input(f"Moving Average (window={window}) RMSE: "))
    ma_mae = float(input(f"Moving Average (window={window}) MAE: "))
    ma_mape = float(input(f"Moving Average (window={window}) MAPE: "))
    models.append({
        'Model': f'Moving Average (window={window})',
        'RMSE': ma_rmse,
        'MAE': ma_mae,
        'MAPE': ma_mape
    })

# ARIMA
arima_rmse = float(input("ARIMA RMSE: "))
arima_mae = float(input("ARIMA MAE: "))
arima_mape = float(input("ARIMA MAPE: "))
models.append({
    'Model': 'ARIMA',
    'RMSE': arima_rmse,
    'MAE': arima_mae,
    'MAPE': arima_mape
})

# Prophet
prophet_rmse = float(input("Prophet RMSE: "))
prophet_mae = float(input("Prophet MAE: "))
prophet_mape = float(input("Prophet MAPE: "))
models.append({
    'Model': 'Prophet',
    'RMSE': prophet_rmse,
    'MAE': prophet_mae,
    'MAPE': prophet_mape
})

# Create DataFrame and sort by RMSE
comparison_df = pd.DataFrame(models)
comparison_df = comparison_df.sort_values('RMSE')

# Display comparison table
print("\nModel Comparison (sorted by RMSE):")
print(comparison_df)

# Plot comparison
plt.figure(figsize=(12, 6))
colors = ['#ff9999', '#66b3ff', '#99ff99', '#ffcc99', '#c2c2f0']

plt.bar(comparison_df['Model'], comparison_df['RMSE'], color=colors[:len(comparison_df)])
plt.title('Model Comparison by RMSE (lower is better)')
plt.ylabel('RMSE')
plt.xticks(rotation=45)
plt.tight_layout()
plt.savefig('model_comparison.png')
plt.show()

# Identify best model
best_model = comparison_df.iloc[0]['Model']
print(f"\nBest performing model based on RMSE: {best_model}")

# Future forecast with best model
print(f"\nRecommendation: Use the {best_model} for your 12-month forecast.")
print("To generate the final 12-month forecast:")

if "Moving Average" in best_model:
    window = int(best_model.split('=')[1].strip(')'))
    print(f"""
    1. Calculate the moving average with window size {window} for the last {window} months of data
    2. Use this average as the forecast for all 12 future months
    """)
elif "ARIMA" in best_model:
    print("""
    1. Train the ARIMA model on the full dataset
    2. Use the model.forecast(steps=12) method to generate predictions for 12 months ahead
    """)
else:  # Prophet
    print("""
    1. Train the Prophet model on the full dataset
    2. Create a future dataframe with prophet_model.make_future_dataframe(periods=12, freq='MS')
    3. Generate predictions with prophet_model.predict(future)
    """)

# Additional insights
print("""
Additional insights from your forecasting project:

1. Sales volatility: Your data shows significant month-to-month variations, which makes forecasting challenging
2. Seasonality: The models capable of capturing seasonality (ARIMA & Prophet) might better capture your yearly patterns
3. Trend: There appears to be an upward trend in sales as shown in the visualizations
4. Extreme values: Your data contains some extreme peaks that are difficult to predict with any model
""")