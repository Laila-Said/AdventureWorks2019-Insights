import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error
from statsmodels.tsa.arima.model import ARIMA
from pmdarima import auto_arima

# Load the data without headers, and specify column names manually
df = pd.read_csv('monthly_sales.csv', header=None, names=['Date', 'MonthlySales', 'OrderCount'])

# Add the first row back as data (it was incorrectly treated as header)
first_row = pd.DataFrame([['2011-05-01', 567020.9498, 43]], columns=['Date', 'MonthlySales', 'OrderCount'])
df = pd.concat([first_row, df], ignore_index=True)

# Convert the Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])

# Set date as index
df = df.set_index('Date')

# Convert MonthlySales to numeric format
df['MonthlySales'] = pd.to_numeric(df['MonthlySales'])

# Create a training and testing split (80% train, 20% test)
train_size = int(len(df) * 0.8)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Use the best ARIMA parameters we found
best_order = (2, 1, 0)
best_seasonal_order = (0, 0, 0, 12)  # No seasonal component

# Fit ARIMA model with the best parameters
arima_model = ARIMA(
    train_data['MonthlySales'],
    order=best_order,
    seasonal_order=best_seasonal_order
)
arima_result = arima_model.fit()

# Forecast for the test period
arima_forecast = arima_result.forecast(steps=len(test_data))

# Calculate metrics
arima_rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], arima_forecast))
arima_mae = mean_absolute_error(test_data['MonthlySales'], arima_forecast)
arima_mape = mean_absolute_percentage_error(test_data['MonthlySales'], arima_forecast)

print("\n====== ARIMA Model Performance ======")
print(f"RMSE: {arima_rmse:.2f}")
print(f"MAE: {arima_mae:.2f}")
print(f"MAPE: {arima_mape:.2f}%")
print("====================================")