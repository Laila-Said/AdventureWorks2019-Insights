import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import warnings
warnings.filterwarnings('ignore')
from sklearn.metrics import mean_squared_error, mean_absolute_error
from statsmodels.tsa.arima.model import ARIMA
from pmdarima import auto_arima

# Load the data without headers, and specify column names manually
df = pd.read_csv('monthly_sales.csv', header=None, names=['Date', 'MonthlySales', 'OrderCount'])

# Add the first row back as data (it was incorrectly treated as header)
first_row = pd.DataFrame([['2011-05-01', 567020.9498, 43]], columns=['Date', 'MonthlySales', 'OrderCount'])
df = pd.concat([first_row, df], ignore_index=True)

# Convert the Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])

# Set date as index
df = df.set_index('Date')

# Convert MonthlySales to numeric format
df['MonthlySales'] = pd.to_numeric(df['MonthlySales'])

# Create a training and testing split (80% train, 20% test)
train_size = int(len(df) * 0.8)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Automatically find the best ARIMA parameters
print("\nFinding optimal ARIMA parameters...")
try:
    auto_model = auto_arima(
        train_data['MonthlySales'],
        seasonal=True,
        m=12,  # Monthly seasonality
        start_p=0, start_q=0,
        max_p=3, max_q=3,  # Limiting to smaller values for faster processing
        d=None,  # Let the model determine 'd'
        trace=True,
        error_action='ignore',
        suppress_warnings=True,
        stepwise=True
    )

    print(f"\nBest ARIMA model: {auto_model}")
    best_order = auto_model.order
    best_seasonal_order = auto_model.seasonal_order

    # Fit ARIMA model with the best parameters
    arima_model = ARIMA(
        train_data['MonthlySales'],
        order=best_order,
        seasonal_order=best_seasonal_order
    )
    arima_result = arima_model.fit()
    print(arima_result.summary())

    # Forecast for the test period
    arima_forecast = arima_result.forecast(steps=len(test_data))

    # Plot the results
    plt.figure(figsize=(14, 7))
    plt.plot(train_data.index, train_data['MonthlySales'], label='Training Data')
    plt.plot(test_data.index, test_data['MonthlySales'], label='Testing Data')
    plt.plot(test_data.index, arima_forecast, label='ARIMA Forecast', color='green')
    plt.title('ARIMA Forecast')
    plt.xlabel('Date')
    plt.ylabel('Sales Amount')
    plt.legend()
    plt.grid(True)
    plt.savefig('arima_forecast.png')
    plt.show()

    # Calculate metrics
    arima_rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], arima_forecast))
    arima_mae = mean_absolute_error(test_data['MonthlySales'], arima_forecast)
    arima_mape = mean_absolute_percentage_error(test_data['MonthlySales'], arima_forecast)

    print(f"\nARIMA Model Performance:")
    print(f"RMSE: {arima_rmse:.2f}")
    print(f"MAE: {arima_mae:.2f}")
    print(f"MAPE: {arima_mape:.2f}%")
except Exception as e:
    print(f"Error in ARIMA modeling: {str(e)}")