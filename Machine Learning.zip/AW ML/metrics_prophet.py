import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.metrics import mean_squared_error, mean_absolute_error
from prophet import Prophet

# Load the data without headers, and specify column names manually
df = pd.read_csv('monthly_sales.csv', header=None, names=['Date', 'MonthlySales', 'OrderCount'])

# Add the first row back as data (it was incorrectly treated as header)
first_row = pd.DataFrame([['2011-05-01', 567020.9498, 43]], columns=['Date', 'MonthlySales', 'OrderCount'])
df = pd.concat([first_row, df], ignore_index=True)

# Convert the Date column to datetime
df['Date'] = pd.to_datetime(df['Date'])

# Set date as index
df_indexed = df.set_index('Date')

# Convert MonthlySales to numeric format
df['MonthlySales'] = pd.to_numeric(df['MonthlySales'])

# Create a training and testing split (80% train, 20% test)
train_size = int(len(df) * 0.8)
train_data = df.iloc[:train_size]
test_data = df.iloc[train_size:]

def mean_absolute_percentage_error(y_true, y_pred):
    y_true, y_pred = np.array(y_true), np.array(y_pred)
    return np.mean(np.abs((y_true - y_pred) / y_true)) * 100

# Prepare data for Prophet (requires 'ds' and 'y' columns)
prophet_data = train_data.rename(columns={'Date': 'ds', 'MonthlySales': 'y'})

# Initialize and fit the model
prophet_model = Prophet(
    yearly_seasonality=True,
    weekly_seasonality=False,
    daily_seasonality=False,
    seasonality_mode='multiplicative'
)
prophet_model.fit(prophet_data)

# Create a dataframe for future predictions
future = prophet_model.make_future_dataframe(periods=len(test_data), freq='MS')
prophet_forecast = prophet_model.predict(future)

# Extract the forecast for the test period
prophet_test_forecast = prophet_forecast.iloc[len(train_data):]['yhat'].values

# Calculate metrics
prophet_rmse = np.sqrt(mean_squared_error(test_data['MonthlySales'], prophet_test_forecast))
prophet_mae = mean_absolute_error(test_data['MonthlySales'], prophet_test_forecast)
prophet_mape = mean_absolute_percentage_error(test_data['MonthlySales'], prophet_test_forecast)

print("\n====== Prophet Model Performance ======")
print(f"RMSE: {prophet_rmse:.2f}")
print(f"MAE: {prophet_mae:.2f}")
print(f"MAPE: {prophet_mape:.2f}%")
print("=======================================")